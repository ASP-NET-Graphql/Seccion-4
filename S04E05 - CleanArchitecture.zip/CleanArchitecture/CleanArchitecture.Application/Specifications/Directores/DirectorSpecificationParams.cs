﻿namespace CleanArchitecture.Application.Specifications.Directores
{
    public class DirectorSpecificationParams : SpecificationParams
    {

    }
}
