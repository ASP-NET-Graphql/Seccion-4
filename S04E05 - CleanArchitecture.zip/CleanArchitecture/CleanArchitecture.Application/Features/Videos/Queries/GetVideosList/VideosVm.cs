﻿namespace CleanArchitecture.Application.Features.Videos.Queries.GetVideosList
{
    public  class VideosVm
    {
        public string? Nombre { get; set; }

        public int StreamerId { get; set; }
       
    }
}
